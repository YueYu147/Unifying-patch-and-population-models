tic

n_sp=2;
n=5;

r_m=1;
K_m=15;

d1=0.1;
d2=0.15;

c1_tot=-3:0.5:2;
c1_total=10.^c1_tot;

c2_tot=-3:0.5:2;
c2_total=10.^c2_tot;

h=0;
sigma=0.7;
rho_all=[0 0.3 0.5];
rho_sp=0.9;

K=K_m*ones(n,1)+h*K_m*(-2:2)';  %%% to be adjusted if n \neq 5
% r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)';  %%% to be adjusted if n \neq 5
r=r_m*ones(n,1);

Biomass=nan(3, 3, 2, length(c1_total), length(c2_total));   %%% rho / mean, q25, q75 / species / c1 / c2

for rho_index=1:length(rho_all)
    rho=rho_all(rho_index)

    for c1_index=1:length(c1_tot)
        c1=c1_total(c1_index)

        parfor c2_index=1:length(c2_tot)
            c2=c2_total(c2_index)

            dis_mode=0;  %%% dispersal, mI=mE=c;
            % dis_mode=1;  %%% colonization, mI=c, mE=0;

            Biomass(rho_index, :, :, c1_index, c2_index)=LV_sde(n_sp,n,r,K,d1,d2,c1,c2,dis_mode,rho,sigma,rho_sp);
        end

    end

end


toc

Biomass_mean=Biomass(:, 1, :, :,:);

% fname_mat = sprintf('single_sde_lv_h_%g_rho_%g_sigma_%g_0908.mat', h, rho, sigma);
% fname_mat = sprintf('two_sde_lv_h_%g_sigma_%g_0909.mat', h, sigma);
% save(fname_mat)



%%%%% rho=0
ratio_1=Biomass_mean(1,1, 1,:,:)./(Biomass_mean(1,1, 1,:,:) + Biomass_mean(1,1, 2,:,:));
ratio_1=reshape(ratio_1, 11,11);
contour(c2_tot, c1_tot, ratio_1, [0.1 0.9], 'Color', [0.2 0.31 0.36], 'LineWidth',2);
hold on

%%%%% rho=0.3
ratio_2=Biomass_mean(2,1, 1,:,:)./(Biomass_mean(2, 1,1,:,:) + Biomass_mean(2,1, 2,:,:));
ratio_2=reshape(ratio_2, 11,11);
contour(c2_tot, c1_tot, ratio_2, [0.1 0.9], 'Color', [0 0.63 0.95], 'LineWidth',2);
hold on

%%%%% rho=0.5
ratio_3=Biomass_mean(3,1, 1,:,:)./(Biomass_mean(3,1, 1,:,:) + Biomass_mean(3,1, 2,:,:));
ratio_3=reshape(ratio_3, 11,11);
contour(c2_tot, c1_tot, ratio_3, [0.1 0.9], 'Color', [0.96 0.33 0.08], 'LineWidth',2);
hold off
axis equal
