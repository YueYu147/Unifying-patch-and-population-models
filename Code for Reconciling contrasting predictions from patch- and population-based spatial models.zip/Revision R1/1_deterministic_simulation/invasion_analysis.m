function invasion_growth = invasion_analysis(n, r, K, d1, d2, c1, c2, invader, dis_mode, perturb)

% dis_mode=0;  %%% dispersal, mI=mE=c;
% dis_mode=1;  %%% colonization, mI=c, mE=0;
% perturb=1 means there are asynchronous perturbations

n_sp=2;
ExtintInterval=1;   %%% period of pulse perturbations
tspan=[0 ExtintInterval];
options=[];
final_time=1e4;     %%% numbers of pulse perturbations


if invader == 2

    y0=[ones(n,1);zeros(n,1)];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%  equilibrium of sp.1  %%%%%%%%

    for i=1:final_time

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);   %%% resulting state as the initial condition for the subsequent timestep

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation

        end 

    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%  equilibrium distribution of sp.2  %%%

    y0(n+1:2*n)=0.005*sum(K)/n;

    for i=1:final_time

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation

        end 

        y0(n+1:2*n)=y0(n+1:2*n)*(0.005*sum(K)/n)/sum(y0(n+1:2*n));

    end

    y0_equilibrium=sum(y0(n+1:2*n));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%  invasion analysis of sp.2  %%%%%%%

    for i=1:n

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation


        end 

    end

    invasion_growth=sum(y0(n+1:2*n))/y0_equilibrium;

end





if invader == 1

    y0=[zeros(n,1);ones(n,1)];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%  equilibrium of sp.2  %%%%%%%%

    for i=1:final_time

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);   %%% resulting state as the initial condition for the subsequent timestep

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation


        end 

    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%  equilibrium distribution of sp.1  %%%

    y0(1:n)=0.005*sum(K)/n;

    for i=1:final_time

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation


        end 

        y0(1:n)=y0(1:n)*(0.005*sum(K)/n)/sum(y0(1:n));

    end

    y0_equilibrium=sum(y0(1:n));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%  invasion analysis of sp.1  %%%%%%%

    for i=1:n

        [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
        y0=y(length(t),:);

        if perturb == 1
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation


        end 

    end

    invasion_growth=sum(y0(1:n))/y0_equilibrium;

end






end