clear all
clc

tic

n_sp=2;    %%% number of species
n=5;       %%% number of patches
r=1;       %%% intrinsic growth rate
K_m=15;    %%% mean of carrying capacity

d1=0.1;    %%% mortality rate of species 1
d2=0.105;  %%% mortality rate of species 2

h=0.1;     %%% (if spatially heterogeneous) variation in K (and r)
% h=0;     %%% (if spatially homogenous)
ext_ratio=0.6;   %%% survival fraction after a pulse perturbation

K=K_m*ones(n,1)+h*K_m*(-2:2)';  
%%% spatially heteogenous carrying capacity, need to adjust if n \neq 5

% r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)'; 
% %%% (if) spatially heteogenous growth rate, need to adjust if n \neq 5

% dis_mode=0;  %%% dispersal, mI=mE=c;
dis_mode=1;  %%% colonization, mI=c, mE=0;

perturb=0;

c1_tot=-5:0.2:-1;    
c1_total=10.^c1_tot;   %%% movement (dispersal/colonization) rate of species 1

c2_tot=-5:0.2:-1;
c2_total=10.^c2_tot;   %%% movement (dispersal/colonization) rate of species 2

invasion_growth_1=nan(length(c1_tot), length(c2_tot));
invasion_growth_2=nan(length(c1_tot), length(c2_tot));

for c1_index=1:length(c1_tot)
    c1=c1_total(c1_index)

    parfor c2_index=1:length(c2_tot)
        c2=c2_total(c2_index);

        invasion_growth_1(c1_index, c2_index) = invasion_analysis(n, r, K, d1, d2, c1, c2, 1, dis_mode, perturb);
        invasion_growth_2(c1_index, c2_index) = invasion_analysis(n, r, K, d1, d2, c1, c2, 2, dis_mode, perturb);

    end

end

toc

mask_1 = invasion_growth_1 > 1;
mask_2 = invasion_growth_2 > 1;  

grade = nan(21, 21);
grade(mask_1) = 1;
grade(mask_2) = grade(mask_2)-1;
%%%% coexist = 0, sp.1 wins = 1, sp.2 wins = -1


% plot Figure S14
subplot(2,3,1)
imagesc(c2_tot, c1_tot, grade)
set(gca,'YDir','normal')
colormap([255, 230, 150; 255 0 0; 255, 150, 230]/255);
clim([-1 1])
shading flat
axis square
hold on
plot([-1 3], [-1 -1], 'k', 'LineWidth', 1) 
plot([-1 3], [3 3], 'k', 'LineWidth', 1) 
xlim([-1 3])
ylim([-1 3])
xticks(-1:3)
yticks(-1:3)
line([-1 3],[-1 3],'Color','k','LineStyle','--','Linewidth',2)