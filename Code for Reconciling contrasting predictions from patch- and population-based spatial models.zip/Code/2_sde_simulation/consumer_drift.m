function dX = consumer_drift(~, X, n_sp, e1, e2, mu, K, d, a, A, mI1, mE1, mI2, mE2, n)

if n_sp==1

    % ensure column
    X = X(:);
    N = X(1:n);    % N_i
    R = X(n+1:2*n);% R_i

    % deterministic drift for N (vector n x 1)
    % note: K may be scalar or vector; convert to column
    if isscalar(K)
        Kvec = K * ones(n,1);
    else
        Kvec = K(:);
    end

    % logistic uptake term, elementwise
    uptake = e1 * mu .* R ./ (Kvec + R);    % n x 1   (be careful if Kvec + R has zeros)
    dNdt = N .* (uptake - d) + mI1 * (sum(N) - N) ./ (n-1) - mE1 * N;

    % deterministic drift for R
    dRdt = a * (A(:) - R) - mu * ( N .* R ./ (Kvec + R) );

    dX = [dNdt; dRdt];   % 10 x 1 column

end

if n_sp==2

    % ensure column
    X = X(:);
    N1 = X(1:n);
    N2 = X(n+1:2*n);
    R = X(2*n+1:3*n);

    % deterministic drift for N (vector n x 1)
    % note: K may be scalar or vector; convert to column
    if isscalar(K)
        Kvec = K * ones(n,1);
    else
        Kvec = K(:);
    end

    % logistic uptake term, elementwise
    uptake1 = e1 * mu .* R ./ (Kvec + R);    % n x 1   (be careful if Kvec + R has zeros)
    uptake2 = e2 * mu .* R ./ (Kvec + R);
    dN1dt = N1 .* (uptake1 - d) + mI1 * (sum(N1) - N1) ./ (n-1) - mE1 * N1;
    dN2dt = N2 .* (uptake2 - d) + mI2 * (sum(N2) - N2) ./ (n-1) - mE2 * N2;

    % deterministic drift for R
    dRdt = a * (A(:) - R) - mu * ( (N1+N2) .* R ./ (Kvec + R) );

    dX = [dN1dt; dN2dt; dRdt];   % 15 x 1 column


end

end