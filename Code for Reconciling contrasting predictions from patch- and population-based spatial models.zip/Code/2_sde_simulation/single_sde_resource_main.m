clear all
clc

tic

n_sp=1;
n=5;

e1=0.15;
e2=0.15;
d=0.5;
a=0.5;
K=20;
mu=10;
A_m=100;

c1_tot=-5:0.5:-1;
c1_total=10.^c1_tot;
c2=0;

h=0.3;
sigma=0.5;
rho_all=[0 0.3 0.5];

A=A_m*ones(n,1)+h*A_m*(-2:2)';  %%% to be adjusted if n \neq 5

Biomass=nan(3, 3, length(c1_total));   %%% rho / mean, q25, q75 / c

for rho_index=1:length(rho_all)
    rho=rho_all(rho_index)

    parfor c1_index=1:length(c1_tot)
        c1=c1_total(c1_index);

        %%% dispersal, mI=mE=c;
        % mI1=c1; mE1=c1;
        %%% colonization, 
        mI1=c1; mE1=0;
        %%% by default
        mI2=0; mE2=0;

        Sigma_patch = sigma^2 * ( (1-rho)*eye(n) + rho*ones(n) );
        L = chol(Sigma_patch, 'lower');
        Lbig = [L; zeros(n, n)];
        drift = @(t, X) consumer_drift(t, X, n_sp, e1, e2, mu, K, d, a, A, mI1, mE1, mI1, mE2, n);
        diffusion = @(t, X) diag([ X(1:n) ; zeros(n,1) ]) * Lbig;
        X0 = [ ones(n,1); A(:) ];
        model = sde(drift, diffusion, 'StartTime', 0, 'StartState', X0);
        [paths, times] = model.simulate(200, 'nTrials', 1000, 'nSteps', 2000);

        sum_over_variables = sum(paths(:,1:n,:), 2);
        mean_over_paths = mean(sum_over_variables, 3);
        q25_over_paths  = prctile(sum_over_variables, 25, 3);
        q75_over_paths  = prctile(sum_over_variables, 75, 3);
        output_mean = mean(mean_over_paths(101:201));
        output_q25 = mean(q25_over_paths(101:201));
        output_q75 = mean(q75_over_paths(101:201));
        Biomass(rho_index, :, c1_index) = [output_mean output_q25 output_q75];


    end

end

toc

Biomass_mean=Biomass(:, 1,:);

% fname_mat = sprintf('single_sde_cr_col_h_%g_sigma_%g.mat', h, sigma);
% save(fname_mat)


%%%% rho=0
plot(c1_tot, reshape(Biomass_mean(1, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0.2 0.31 0.36], 'MarkerSize', 6);
hold on

%%%% rho=0.3
plot(c1_tot, reshape(Biomass_mean(2, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0 0.63 0.95], 'MarkerSize', 6);
hold on

%%%% rho=0.5
plot(c1_tot, reshape(Biomass_mean(3, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0.96 0.33 0.08], 'MarkerSize', 6);
hold off

xlim([-5 -1])
xticks(-5:-1)

axis square
