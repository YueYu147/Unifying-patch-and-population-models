clear all
clc

tic

n_sp=2;
n=5;

e1=0.16;
e2=0.15;
d=0.5;
a=0.5;
K=20;
mu=10;
A_m=100;

c1_tot=-5:0.5:-1;
c1_total=10.^c1_tot;
c2_tot=-5:0.5:-1;
c2_total=10.^c2_tot;

h=0.3;
sigma=0.5;
rho_all=[0 0.3 0.5];
rho_sp=0.9;

A=A_m*ones(n,1)+h*A_m*(-2:2)';  %%% to be adjusted if n \neq 5

Biomass=nan(3, 3, 2, length(c1_total), length(c2_total));   %%% rho / mean, q25, q75 / species / c1 / c2

for rho_index=1:length(rho_all)
    rho=rho_all(rho_index)

    for c1_index=1:length(c1_tot)
        c1=c1_total(c1_index)

        parfor c2_index=1:length(c2_tot)
            c2=c2_total(c2_index);

%             dis_mode=0;  %%% dispersal, mI=mE=c;
%             mI1=c1; mE1=c1;
%             mI2=c2; mE2=c2;
            % dis_mode=1;  %%% colonization, mI=c, mE=0;
            mI1=c1; mE1=0;
            mI2=c2; mE2=0;

            drift = @(t, X) consumer_drift(t, X, n_sp, e1, e2, mu, K, d, a, A, mI1, mE1, mI2, mE2, n);

            Sigma_species = [1, rho_sp; rho_sp, 1];
            Sigma_patch = (1-rho)*eye(n) + rho*ones(n);
            Sigma = sigma^2 * kron(Sigma_species, Sigma_patch);
            L = chol(Sigma, 'lower');   %%% 10*10
            Lbig = [L; zeros(5,10)];    %%% 15*10
            diffusion = @(t, X) diag([ X(1:2*n) ; zeros(n,1) ]) * Lbig;

            X0 = [ ones(2*n,1); A(:) ];
            model = sde(drift, diffusion, 'StartTime', 0, 'StartState', X0);
            [paths, times] = model.simulate(200, 'nTrials', 200, 'nSteps', 2000);

            sum_over_variables = [sum(paths(:,1:5,:), 2), sum(paths(:,6:10,:), 2)];
            mean_over_paths = mean(sum_over_variables, 3);   %%% 201*2
            q25_over_paths  = prctile(sum_over_variables, 25, 3);
            q75_over_paths  = prctile(sum_over_variables, 75, 3);
            output_mean = mean(mean_over_paths(101:201,:),1);
            output_q25 = mean(q25_over_paths(101:201,:),1);
            output_q75 = mean(q75_over_paths(101:201,:),1);
            Biomass(rho_index, :, :, c1_index, c2_index) = [output_mean; output_q25; output_q75];
        end

    end

end


toc

Biomass_mean=Biomass(:, 1,:,:,:);

% fname_mat = sprintf('two_sde_cr_col_h_%g_sigma_%g_e1_%g.mat', h, sigma, e1);
% save(fname_mat)

%%%%% rho=0
ratio_1=Biomass_mean(1,1, 1,:,:)./(Biomass_mean(1,1, 1,:,:) + Biomass_mean(1,1, 2,:,:));
ratio_1=reshape(ratio_1, 9,9);
contour(c2_tot, c1_tot, ratio_1, [0.1 0.9], 'Color', [0.2 0.31 0.36], 'LineWidth',2, "ShowText","on");
hold on

%%%% rho=0.3
ratio_2=Biomass_mean(2,1, 1,:,:)./(Biomass_mean(2, 1,1,:,:) + Biomass_mean(2,1, 2,:,:));
ratio_2=reshape(ratio_2, 9,9);
contour(c2_tot, c1_tot, ratio_2, [0.1 0.9], 'Color', [0 0.63 0.95], 'LineWidth',2, "ShowText","on");
hold on

%%%%% rho=0.5
ratio_3=Biomass_mean(3,1, 1,:,:)./(Biomass_mean(3,1, 1,:,:) + Biomass_mean(3,1, 2,:,:));
ratio_3=reshape(ratio_3, 9,9);
contour(c2_tot, c1_tot, ratio_3, [0.1 0.9], 'Color', [0.96 0.33 0.08], 'LineWidth',2, "ShowText","on");
hold off
axis equal
