function output = LV_sde(n_sp,n,r,K,d1,d2,c1,c2,dis_mode,rho,sigma, rho_sp)

if dis_mode==0  %%% dispersal
    mI1=c1;mE1=c1;
    mI2=c2;mE2=c2;
elseif dis_mode==1  %%% colonization
    mI1=c1; mE1=0;
    mI2=c2;mE2=0;
end

if n_sp == 1

    drift = @(t, N) r .* N .* (1 - N ./ K) -d1*N + mI1 * (sum(N) - N) ./ (n-1) - mE1 * N;
    
    Sigma = sigma^2 * ((1-rho)*eye(n) + rho*ones(n));
    % Cholesky decomposition, Sigma = L*L' and L is a lower triangular matrix
    L = chol(Sigma, 'lower');
    diffusion = @(t, N) diag(N) * L;

    model = sde(drift, diffusion, 'StartTime', 0, 'StartState', ones(n,1));
    [paths, times] = model.simulate(200, 'nTrials', 1000, 'nSteps', 2000);

    sum_over_variables = sum(paths, 2);
    mean_over_paths = mean(sum_over_variables, 3);
    q25_over_paths  = prctile(sum_over_variables, 25, 3);
    q75_over_paths  = prctile(sum_over_variables, 75, 3);
    
    output_mean = mean(mean_over_paths(101:201));
    output_q25 = mean(q25_over_paths(101:201));
    output_q75 = mean(q75_over_paths(101:201));
    output = [output_mean output_q25 output_q75];
  
end

if n_sp == 2

    drift = @(t, N) [

    % ---- Species 1 ----
    r .* N(1:n) .* (1 - (N(1:n) + N(n+1:2*n)) ./ K) ...
    - d1 .* N(1:n) ...
    + mI1 .* (sum(N(1:n)) - N(1:n)) ./ (n-1) ...
    - mE1 .* N(1:n);
    
    % ---- Species 2 ----
    r .* N(n+1:2*n) .* (1 - (N(1:n) + N(n+1:2*n)) ./ K) ...
    - d2 .* N(n+1:2*n) ...
    + mI2 .* (sum(N(n+1:2*n)) - N(n+1:2*n)) ./ (n-1) ...
    - mE2 .* N(n+1:2*n)
];


    Sigma_species = [1, rho_sp; rho_sp, 1];
    Sigma_patch = (1-rho)*eye(n) + rho*ones(n);
    Sigma = sigma^2 * kron(Sigma_species, Sigma_patch);
    L = chol(Sigma, 'lower');
    diffusion = @(t, N) diag(N) * L;

    model = sde(drift, diffusion, 'StartTime', 0, 'StartState', ones(2*n, 1));
    [paths, times] = model.simulate(200, 'nTrials', 100, 'nSteps', 2000);

    sum_over_variables = [sum(paths(:,1:5,:), 2), sum(paths(:,6:10,:), 2)];
    mean_over_paths = mean(sum_over_variables, 3);     %%% 201*2
    q25_over_paths  = prctile(sum_over_variables, 25, 3);
    q75_over_paths  = prctile(sum_over_variables, 75, 3);
    % % plot(times, mean_over_paths, 'LineWidth', 1.5);
    output_mean = mean(mean_over_paths(101:201,:),1);
    output_q25 = mean(q25_over_paths(101:201,:),1);
    output_q75 = mean(q75_over_paths(101:201,:),1);
    output = [output_mean; output_q25; output_q75];   %%% 3*2

end