clear all
clc

tic

n_sp=1;    %%% number of species
n=5;       %%% number of patches

r_m=1;     %%% mean of intrinsic growth rate
K_m=15;    %%% mean of carrying capacity

d1=0.1;    %%% mortality rate of species 1
d2=0.105;  %%% mortality rate of species 2

c1_tot=-3:0.5:2;
c1_total=10.^c1_tot;   %%% movement (dispersal/colonization) rate of species 1
c2=0;   %%% movement (dispersal/colonization) rate of species 2

h=0;   %%% variation in K (and r)
sigma=0.7;
rho_all=[0 0.3 0.5];

K=K_m*ones(n,1)+h*K_m*(-2:2)';  %%% to be adjusted if n \neq 5
% r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)';  %%% to be adjusted if n \neq 5
r=r_m*ones(n,1);

Biomass=nan(3, 3, length(c1_total));   %%% 3 dimensions: rho / mean, q25, q75 / c

for rho_index=1:length(rho_all)
    rho=rho_all(rho_index)

    parfor c1_index=1:length(c1_tot)
        c1=c1_total(c1_index);

        dis_mode=0;  %%% dispersal, mI=mE=c;
        % dis_mode=1;  %%% colonization, mI=c, mE=0;

        Biomass(rho_index, :, c1_index)=LV_sde(n_sp,n,r,K,d1,d2,c1,c2,dis_mode,rho,sigma);

    end

end


toc

Biomass_mean=Biomass(:, 1,:);
% q25=Biomass(:,2,:);
% q75=Biomass(:,3,:);

% fname_mat = sprintf('single_sde_lv_h_%g_sigma_%g.mat', h, sigma);
% save(fname_mat)

% plot Figures 3 and S1
%%%% rho=0
plot(c1_tot, reshape(Biomass_mean(1, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0.2 0.31 0.36], 'MarkerSize', 6);
hold on

%%%% rho=0.3 
plot(c1_tot, reshape(Biomass_mean(2, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0 0.63 0.95], 'MarkerSize', 6);
hold on

%%%% rho=0.5
plot(c1_tot, reshape(Biomass_mean(3, :, :), length(c1_tot), 1), 'LineWidth', 3, 'Color', [0.96 0.33 0.08], 'MarkerSize', 6);
hold off

xlim([-3 2])
xticks(-3:2)

axis square

% fname_fig = sprintf('h_%g_sigma_%g.png', h, sigma);
% saveas(gcf, fname_fig)
% close;