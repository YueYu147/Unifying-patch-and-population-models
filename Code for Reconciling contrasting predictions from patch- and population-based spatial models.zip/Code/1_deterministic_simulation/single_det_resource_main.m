clear all
clc

tic

n_sp=1;   %%% number of species
n=5;      %%% number of patches

e1=0.15;  %%% resource conversion efficiency of species 1
e2=0.15;  %%% resource conversion efficiency of species 2 (by default)
m=0.5;    %%% mortality rate (d in Equation 3a of maintext) 
a=0.5;    %%% resource supply turnover rate
K=20;     %%% half-saturation constant (R_K in Equation 3a of maintext)    
mu=10;    %%% maximum growth rate
A_m=100;  %%% mean of resource supply concentration

c1_tot=-5:0.2:2;
c1_total=10.^c1_tot;   %%% movement (dispersal/colonization) rate of species 1
c2=0;   %%% movement (dispersal/colonization) rate of species 2 (by default)

ext_ratio=0.6;   %%% survival fraction after an asynchronous perturbation
ext_ratio_all=0.92;   %%% survival fraction after a synchronous perturbation

ExtintInterval=1;   %%% period of pulse perturbations
tspan=[0 ExtintInterval];
options=[];

final_time=1e4;     %%% number of pulse perturbations

dis_mode=0;  %%% dispersal, mI=mE=c;
% dis_mode=1;  %%% colonization, mI=c, mE=0;

Biomass=nan(3, length(c1_tot));   %%% biomass of species on each patch

for sce=1:3

    if sce == 2 || sce == 3
        h=0.3;   %%% (if spatially heterogeneous) variation in A
    elseif sce == 1
        h=0;     %%% if spatially homogenous
    end


    parfor c1_index=1:length(c1_tot)
        c1=c1_total(c1_index);

        A=A_m*ones(n,1)+h*A_m*(-2:2)';
        %%% spatially heteogenous resource supply concentration, need to adjust if n \neq 5
        y0=[ones(n,1); A];
        %%% initial values, all N_i=1, R=A (resource levels = supply concentration A)

        for i=1:final_time

            [t,y]=ode45('det_resource_ode',tspan,y0,options,n_sp,n,c1,c2,e1,e2,m,a,A,mu,K,dis_mode);   %%% ode simulation
            y0=y(length(t),:);    %%% resulting state as the initial condition for the subsequent timestep

            if i==final_time
                Biomass(sce, c1_index)=sum(y0(1:5));
            end

            if sce == 1 || sce == 3  %%%  asynchronous perturbations
                ExtincIndex = rem(i,n);   %%% the patch being disturbed
                if ExtincIndex == 0
                    ExtincIndex = n;
                end
                y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;

            elseif sce == 2          %%%  synchronous perturbations

               y0(1:5)=y0(1:5)*ext_ratio_all;

            end
        end

    end

end


toc

% plot Figures 2c, f 

Biomass_stan=nan(3, length(c1_tot));   %%% change in metapopulation size

for sce=1:3
    for c1_index=1:length(c1_tot)
        Biomass_stan(sce,:)=Biomass(sce,:)-Biomass(sce,1);
    end
end

color=[210 107 102; 83 120 172; 68 153 69; 0 18 25]/255;

for sce=1:3
    plot(c1_tot, Biomass_stan(sce,:),...
        '-', "Color", color(sce,:), "LineWidth", 2)
    xticks(-3:1)
    xlim([-3 1])
    hold on
end
plot(c1_tot, Biomass_stan(1,:)+Biomass_stan(2,:), "o",...
    'MarkerSize',4,...
    'MarkerEdgeColor', color(4,:),...
    'Linewidth', 1)
hold off
legend('1','2','3','1+2')