clear all
clc

tic

n_sp=1;   %%% number of species
n=5;      %%% number of patches

r_m=1;    %%% mean of intrinsic growth rate
K_m=15;   %%% mean of carrying capacity

d1=0.1;    %%% mortality rate of species 1
d2=0.105;  %%% mortality rate of species 2 (by default)

c1_tot=-2:0.2:2;   
c1_total=10.^c1_tot;   %%% movement (dispersal/colonization) rate of species 1
c2=0;   %%% movement (dispersal/colonization) rate of species 2 (by default)

ext_ratio=0.6;   %%% survival fraction after an asynchronous perturbation
ext_ratio_all=0.92;   %%% survival fraction after a synchronous perturbation

ExtintInterval=1;   %%% period of pulse perturbations
tspan=[0 ExtintInterval];
options=[];

final_time=1e4;   %%% number of pulse perturbations

Biomass=nan(3, length(c1_tot));   %%% biomass of species on each patch

for sce=1:3

    if sce == 1 || sce == 3
        h=0.1;   %%% (if spatially heterogeneous) variation in K (and r)
    elseif sce == 2
        h=0;     %%% if spatially homogenous
    end


    K=K_m*ones(n,1)+h*K_m*(-2:2)'; 
    %%% spatially heteogenous carrying capacity, need to adjust if n \neq 5

    % if r is heterogeneous:
    r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)';  %%% to be adjusted if n \neq 5
    % if r is homogeneous:
    % r=r_m*ones(n,1); 

    parfor c1_index=1:length(c1_tot)
        c1=c1_total(c1_index)

        y0=ones(n,1);   %%% initial values, all N_i=1

        for i=1:final_time

            dis_mode=0;  %%% dispersal, mI=mE=c;
            % dis_mode=1;  %%% colonization, mI=c, mE=0;

            [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
            y0=y(length(t),:);   %%% resulting state as the initial condition for the subsequent timestep

            if i==final_time
                Biomass(sce, c1_index)=sum(y0);
            end

            if sce == 2 || sce == 3  %%%  asynchronous perturbations
                ExtincIndex = rem(i,n);   %%% the patch being disturbed
                if ExtincIndex == 0
                    ExtincIndex = n;
                end
                y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;

            elseif sce == 1          %%%  synchronous perturbations

               y0=y0*ext_ratio_all;

            end
        end

    end

end

toc


% plot Figures 2a, b, d, e 

Biomass_stan=nan(3, length(c1_tot));

for sce=1:3
    for c1_index=1:length(c1_tot)
        Biomass_stan(sce,:)=Biomass(sce,:)-Biomass(sce,1);
    end
end

color=[83 120 172; 210 107 102; 68 153 69; 0 18 25]/255;

for sce=1:3
    plot(c1_tot, Biomass_stan(sce,:),...
        '-', "Color", color(sce,:), "LineWidth", 3)
    xticks(-2:2)
    xlim([-2 2])
    hold on
end
plot(c1_tot, Biomass_stan(1,:)+Biomass_stan(2,:), "o",...
    'MarkerSize',4,...
    'MarkerEdgeColor', color(4,:),...
    'Linewidth', 1)
hold off
legend('1','2','3','1+2')