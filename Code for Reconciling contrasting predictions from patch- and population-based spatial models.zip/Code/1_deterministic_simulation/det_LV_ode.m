function dydt = det_LV_ode(t,y,flag,n_sp,n,r,K,d1,d2,c1,c2,dis_mode)

if dis_mode==0  %%% dispersal
    mI1=c1; mE1=c1;
    mI2=c2; mE2=c2;
elseif dis_mode==1  %%% colonization
    mI1=c1; mE1=0;
    mI2=c2; mE2=0;
end

if n_sp == 1   %%% Equation 1, 2 and 4 in maintext
    N = y(1:n);
    dNdt=r.*N.*(1-N./K)-d1*N+mI1*(sum(N)-N)/(n-1)-mE1*N;
    dydt=dNdt;
end

if n_sp == 2   %%% Equation 1, 2 and 4 in maintext
    N1 = y(1:n);
    N2 = y(n+1:2*n);
    dN1dt=r.*N1.*(1-(N1+N2)./K)-d1*N1+mI1*(sum(N1)-N1)/(n-1)-mE1*N1;
    dN2dt=r.*N2.*(1-(N1+N2)./K)-d2*N2+mI2*(sum(N2)-N2)/(n-1)-mE2*N2;
    dydt=[dN1dt;dN2dt];
end