clear all
clc

tic

n_sp=2;    %%% number of species
n=5;       %%% number of patches
r=1;       %%% intrinsic growth rate
K_m=15;    %%% mean of carrying capacity

d1=0.1;    %%% mortality rate of species 1
d2=0.105;  %%% mortality rate of species 2

h=0.1;     %%% (if spatially heterogeneous) variation in K (and r)
% h=0;     %%% (if spatially homogenous)
ext_ratio=0.6;   %%% survival fraction after a pulse perturbation

K=K_m*ones(n,1)+h*K_m*(-2:2)';  
%%% spatially heteogenous carrying capacity, need to adjust if n \neq 5

% r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)'; 
% %%% (if) spatially heteogenous growth rate, need to adjust if n \neq 5

ExtintInterval=1;   %%% period of pulse perturbations
tspan=[0 ExtintInterval];
options=[];

final_time=1e4;     %%% numbers of pulse perturbations

c1_tot=-1:0.2:3;    
c1_total=10.^c1_tot;   %%% movement (dispersal/colonization) rate of species 1

c2_tot=-1:0.2:3;
c2_total=10.^c2_tot;   %%% movement (dispersal/colonization) rate of species 2

Biomass=nan(length(c1_tot), length(c2_tot), 2*n);   %%% biomass of each species on each patch

for c1_index=1:length(c1_tot)
    c1=c1_total(c1_index)

    parfor c2_index=1:length(c2_tot)
        c2=c2_total(c2_index);

        y0=ones(2*n,1);   %%% initial values, all N_ik=1

        for i=1:final_time

            dis_mode=0;  %%% dispersal, mI=mE=c;
            % dis_mode=1;  %%% colonization, mI=c, mE=0;

            [t,y]=ode45('det_LV_ode',tspan,y0,options,n_sp,n,r,K,d1,d2,c1,c2,dis_mode);   %%% ode simulation
            y0=y(length(t),:);   %%% resulting state as the initial condition for the subsequent timestep

            if i==final_time
                Biomass(c1_index, c2_index, :)=y0;
            end

            %%% (if) asynchronous perturbations
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;   
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation

            % %%% (if) synchronous perturbations
            % y0=y0*(1-(1-ext_ratio)/n);

        end

    end

end

toc

Biomass_1=Biomass(:,:,1:5);
Biomass_2=Biomass(:,:,6:10);
Biomass_1_sum=sum(Biomass_1,3);
Biomass_2_sum=sum(Biomass_2,3);
grade=Biomass_1_sum./(Biomass_1_sum+Biomass_2_sum);  %%% N_1/(N_1+N_2)

% plot Figures 4 and S6
contourf(c2_tot, c1_tot, grade, [0, 0.1], 'LineStyle', 'none', 'FaceColor', [255, 230, 150]/255);
hold on
contourf(c2_tot, c1_tot, grade, [0.1, 0.9], 'LineStyle', 'none', 'FaceColor', [255 0 0]/255);
contourf(c2_tot, c1_tot, grade, [0.9, 1], 'LineStyle', 'none', 'FaceColor', [255, 150, 230]/255);
axis square
% line([-5 -1],[-5 -1],'Color','k','LineStyle','--','Linewidth',2)