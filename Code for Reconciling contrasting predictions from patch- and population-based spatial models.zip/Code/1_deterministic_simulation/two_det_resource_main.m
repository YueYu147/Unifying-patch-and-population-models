clear all
clc

tic

n_sp=2;    %%% number of species
n=5;       %%% number of patches

e1=0.1505;   %%% resource conversion efficiency of species 1
e2=0.15;     %%% resource conversion efficiency of species 2
m=0.5;       %%% mortality rate (d in Equation 3a of maintext) 
a=0.5;       %%% resource supply turnover rate
K=20;        %%% half-saturation constant (R_K in Equation 3a of maintext)  
mu=10;       %%% maximum growth rate
A_m=100;     %%% mean of resource supply concentration

h=0.3;   %%% (if spatially heterogeneous) variation in A
% h=0;   %%% if spatially homogenous
ext_ratio=0.6;   %%% survival fraction after an asynchronous perturbation

A=A_m*ones(n,1)+h*A_m*(-2:2)';
%%% spatially heteogenous resource supply concentration, need to adjust if n \neq 5

ExtintInterval=1;   %%% period of pulse perturbations
tspan=[0 ExtintInterval];
options=[];
final_time=1e5;   %%% number of pulse perturbations

c1_tot=-5:0.2:-1;
c1_total=10.^c1_tot;    %%% movement (dispersal/colonization) rate of species 1

c2_tot=-5:0.2:-1;
c2_total=10.^c2_tot;    %%% movement (dispersal/colonization) rate of species 2

Biomass=nan(length(c1_tot), length(c2_tot), 2*n);   %%% biomass of species on each patch

for c1_index=1:length(c1_tot)
    c1=c1_total(c1_index)

    parfor c2_index=1:length(c2_tot)
        c2=c2_total(c2_index);

        y0=[ones(n,2) A];    %%% initial values, all N_i=1, R=A (resource levels = supply concentration A)

        for i=1:final_time

            % dis_mode=0;  %%% dispersal, mI=mE=c;
            dis_mode=1;  %%% colonization, mI=c, mE=0;

            [t,y]=ode45('det_resource_ode',tspan,y0,options,n_sp,n,c1,c2,e1,e2,m,a,A,mu,K,dis_mode);   %%% ode simulation
            y0=y(length(t),:);   %%% resulting state as the initial condition for the subsequent timestep

            if i==final_time
                Biomass(c1_index, c2_index, :) = y0(1:2*n);
            end

            %%% asynchronous perturbations
            ExtincIndex = rem(i,n);   %%% the patch being disturbed
            if ExtincIndex == 0
                ExtincIndex = n;
            end
            y0(ExtincIndex)=y0(ExtincIndex)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 1 is removed due to perturbation
            y0(ExtincIndex+n)=y0(ExtincIndex+n)*ext_ratio;
            %%% fraction (1-ext_ratio) of species 2 is removed due to perturbation

            % %%% synchronous perturbations
            % y0=y0*(1-(1-ext_ratio)/n);

        end

    end

end

toc

Biomass_1=Biomass(:,:,1:5);
Biomass_2=Biomass(:,:,6:10);
Biomass_1_sum=sum(Biomass_1,3);
Biomass_2_sum=sum(Biomass_2,3);
grade=Biomass_1_sum./(Biomass_1_sum+Biomass_2_sum);   %%% N_1/(N_1+N_2)

% plot Figure S7
contourf(c2_tot, c1_tot, grade, [0, 0.1], 'LineStyle', 'none', 'FaceColor', [255, 230, 150]/255);
hold on
contourf(c2_tot, c1_tot, grade, [0.1, 0.9], 'LineStyle', 'none', 'FaceColor', [255 0 0]/255);
contourf(c2_tot, c1_tot, grade, [0.9, 1], 'LineStyle', 'none', 'FaceColor', [255, 150, 230]/255);