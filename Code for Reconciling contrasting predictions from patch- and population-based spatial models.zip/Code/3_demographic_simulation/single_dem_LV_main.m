clear all
clc

tic

r_m=1;
K_m=100;

d=0.1; %% death rate

% % dispersal
% dis_mode=0;
% loopnum=100;
% max_time=100;
% %%% corresoponds to 6~8e4 birth/death events
% valid_num=1e3;
% c_tot=-5:0.5:2;
% c_total=10.^c_tot;

% colonization
dis_mode=1;
loopnum=100;
max_time=100;
valid_num=1;
c_tot=-5:0.5:-1;
c_total=10.^c_tot;

n=5;
h=0; 
%%%% scenario 1: h=0;
%%%% scenario 3: h=0.3;

K=K_m*ones(n,1)+h*K_m*(-2:2)';  %%% to be adjusted if n \neq 5
r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)';  %%% to be adjusted if n \neq 5
%%% r=r_m*ones(n,1);

options=[];
c2=0;

State_Output=nan(length(c_total), loopnum);
event_num=zeros(length(c_total), loopnum);
real_time=zeros(length(c_total), loopnum);


for loop=1:loopnum
    loop

    parfor c_index=1:length(c_tot)
        c=c_total(c_index);

        state=ones(n,1);

        tot_time=0;
        tot_num=0;

        %%%%%%%%%% max_time %%%%%%%%%%

        while tot_time<max_time

            N=state;
            birth=r.*N;
            death=-r.*N.*N./K-d*N;
            propen=[birth; death];

            time_rand=unifrnd(0, 1, 2*n, 1);
            tau=abs(log(time_rand)./propen);
            [mintau, minindex]=min(tau);

            tspan=[0 mintau];
            y0=state;
            [t,y]=ode45('dem_LV_dispersal',tspan,y0,options,n,1,c,c2,dis_mode);
            state=y(length(t),1:n)';

            state_change=zeros(n, 1);  %% initial val

            if minindex<=n
                state_change(minindex,1)=1;
            elseif minindex>n
                state_change(minindex-n,1)=-1;
            end

            state=state+state_change;
            % state_num(:,num)=state;
            state(state<0)=0;

            tot_num=tot_num+1;
            tot_time=tot_time+mintau;

            if mintau==Inf  %% which means all Ns = 0
                break
            end

        end

        real_time(c_index, loop)=tot_time;
        event_num(c_index, loop)=tot_num;


        %%%%%%%%%% valid_num %%%%%%%%%%
        
        num2=0;
        state_valid=zeros(valid_num, 1);

        while num2<valid_num

            N=state;
            birth=r.*N;
            death=-r.*N.*N./K-d*N;
            propen=[birth; death];

            time_rand=unifrnd(0, 1, 2*n, 1);
            tau=abs(log(time_rand)./propen);
            [mintau, minindex]=min(tau);

            tspan=[0 mintau];
            y0=state;
            [t,y]=ode45('dem_LV_dispersal',tspan,y0,options,n,1,c,c2,dis_mode);
            state=y(length(t),1:n)';

            state_change=zeros(n, 1);  %% initial val

            if minindex<=n
                state_change(minindex,1)=1;
            elseif minindex>n
                state_change(minindex-n,1)=-1;
            end

            state=state+state_change;
            % state_num(:,num)=state;
            state(state<0)=0;

            num2=num2+1;
            state_valid(num2)=sum(state);

            real_time(c_index, loop)=real_time(c_index, loop)+mintau;

            if mintau==Inf  %% which means all Ns = 0
                break
            end

        end

        state_valid_mean=mean(state_valid);
        State_Output(c_index, loop) = state_valid_mean;
    end

end

toc


q25 = prctile(State_Output, 25, 2);
q75 = prctile(State_Output, 75, 2);
Biomass_mean=mean(State_Output,2);


pf=fill([c_tot,fliplr(c_tot)],[q25',fliplr(q75')],[239 191 189]/255);
pf.EdgeColor = 'none';
hold on
plot(c_tot, Biomass_mean, 'LineWidth', 2, 'Color', [210 107 102]/255, 'MarkerSize', 6);
% plot(c_tot, Biomass_mean, 'LineWidth', 2, 'Color', [68 153 69]/255, 'MarkerSize', 6);
xlim([-5 -1])
xticks(-5:-1)