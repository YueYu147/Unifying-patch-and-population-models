clear all
clc

tic

e=0.15;
m=0.5;
a=1;
K=50;
mu=10;
A_m=300;
gamma=1;
e1=0.15;


% dispersal
dis_mode=0;
loopnum=1000;
max_time=200;
%%% corresoponds to 6~8e4 birth/death events
valid_num=1e3;
c_tot=-5:0.5:2;
c_total=10.^c_tot;

% % colonization
% dis_mode=1;
% loopnum=100;
% max_time=200;
% valid_num=1;
% c_tot=-5:0.5:-1;
% c_total=10.^c_tot;

n=5;
h=0; 
%%%% scenario 1: h=0;
%%%% scenario 3: h=0.3;

A=A_m*ones(n,1)+h*A_m*(-2:2)';  %%% to be adjusted if n \neq 5
options=[];
c2=0;

State_Output=nan(length(c_total), loopnum);
event_num=zeros(length(c_total), loopnum);
real_time=zeros(length(c_total), loopnum);


for loop=1:loopnum
    loop

    parfor c_index=1:length(c_tot)  
        c=c_total(c_index);

        state=[ones(n,1) A];

        tot_time=0;
        tot_num=0;

        %%%%%%%%%% max_time %%%%%%%%%%

        while tot_time<max_time

            N1=state(:,1);
            R=state(:,2);
            growth=gamma*N1.*e1*mu.*R./(K+R);
            death=gamma*N1*m;
            propen=[growth; death];

            time_rand=unifrnd(0, 1, 2*n, 1);
            tau=abs(log(time_rand)./propen);
            [mintau, minindex]=min(tau);

            tspan=[0 mintau];
            y0=[state(:,1); state(:,2);];
            [t,y]=ode45('dem_resource_dispersal',tspan,y0,options,n,1,c,c2,a,A,mu,K,gamma,dis_mode);
            state(:,1)=y(length(t),1:n)';
            state(:,2)=y(length(t),n+1:2*n)';

            state_change=zeros(n, 2);  %% initial value

            if minindex<=n
                state_change(minindex,1)=1;
            elseif minindex>n
                state_change(minindex-n,1)=-1;
            end

            state=state+state_change;
            state(state<0)=0;

            tot_num=tot_num+1;
            tot_time=tot_time+mintau;

            if mintau==Inf  %% which means all Ns = 0
                break
            end

        end

        real_time(c_index, loop)=tot_time;
        event_num(c_index, loop)=tot_num;


        %%%%%%%%%% valid_num %%%%%%%%%%
        
        num2=0;
        state_valid=zeros(valid_num, 1);

        while num2<valid_num

           N1=state(:,1);
            R=state(:,2);
            growth=gamma*N1.*e1*mu.*R./(K+R);
            death=gamma*N1*m;
            propen=[growth; death];

            time_rand=unifrnd(0, 1, 2*n, 1);
            tau=abs(log(time_rand)./propen);
            [mintau, minindex]=min(tau);

            tspan=[0 mintau];
            y0=[state(:,1);state(:,2)];
            [t,y]=ode45('dem_resource_dispersal',tspan,y0,options,n,1,c,c2,a,A,mu,K,gamma,dis_mode);
            state(:,1)=y(length(t),1:n)';
            state(:,2)=y(length(t),n+1:2*n)';

            state_change=zeros(n, 2);  %% initial value

            if minindex<=n
                state_change(minindex,1)=1;
            elseif minindex>n
                state_change(minindex-n,1)=-1;
            end

            state=state+state_change;
            state(state<0)=0;

            num2=num2+1;
            state_valid(num2)=sum(state(:,1));

            real_time(c_index, loop)=real_time(c_index, loop)+mintau;

            if mintau==Inf  %% which means all Ns = 0
                break
            end

        end

        state_valid_mean=mean(state_valid);
        State_Output(c_index, loop) = state_valid_mean;
    end

end

toc

%%%%% Plot Figures S5

q25 = prctile(State_Output, 25, 2);
q75 = prctile(State_Output, 75, 2);
Biomass_mean=mean(State_Output,2);

pf=fill([c_tot,fliplr(c_tot)],[q25',fliplr(q75')],[239 191 189]/255);
pf.EdgeColor = 'none';
hold on
plot(c_tot, Biomass_mean, 'LineWidth', 2, 'Color', [210 107 102]/255, 'MarkerSize', 6);
% plot(c_tot, Biomass_mean, 'LineWidth', 2, 'Color', [68 153 69]/255, 'MarkerSize', 6);
xlim([-5 2])
xticks(-5:2)