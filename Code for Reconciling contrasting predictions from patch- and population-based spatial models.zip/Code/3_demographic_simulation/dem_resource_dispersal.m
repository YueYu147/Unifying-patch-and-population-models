function dydt = dem_resource_dispersal(t,y,flag,n,n_sp,c1,c2,a,A,mu,K,gamma,dis_mode)

if dis_mode==0  %%% dispersal
    mI1=c1;mE1=c1;
    mI2=c2;mE2=c2;
elseif dis_mode==1  %%% colonization
    mI1=c1; mE1=0;
    mI2=c2;mE2=0;
end

if n_sp==1

    N1 = y(1:n);
    R = y(n+1:2*n);
    dN1dt=mI1*(sum(N1)-N1)/(n-1)-mE1*N1;
    dRdt=gamma*( a.*(A-R) -mu.*N1.*R./(K+R) );
    dydt=[dN1dt;dRdt];

elseif n_sp==2

    N1 = y(1:n);
    N2 = y(n+1:2*n);
    R = y(2*n+1:3*n);
    dN1dt=mI1*(sum(N1)-N1)/(n-1)-mE1*N1;
    dN2dt=mI2*(sum(N2)-N2)/(n-1)-mE2*N2;
    dRdt=gamma*( a.*(A-R) -mu.*N1.*R./(K+R) -mu.*N2.*R./(K+R) );
    dydt=[dN1dt;dN2dt;dRdt];

end

end