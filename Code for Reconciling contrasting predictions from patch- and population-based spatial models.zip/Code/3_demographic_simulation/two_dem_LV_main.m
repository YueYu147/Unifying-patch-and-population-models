clear all

tic

r_m=1;
K_m=100;

d1=0.1;
d2=0.25;  

% %%% dispersal
% dis_mode=0;
% c_tot=-5:0.5:2;

% %%% colonization
dis_mode=1;
c_tot=-4:0.2:-1;

c1_total=10.^c_tot;
c2_total=10.^c_tot;

n=5;
h=0;
%%%% scenario 1: h=0;
%%%% scenario 3: h=0.3;

K=K_m*ones(n,1)+h*K_m*(-2:2)';  %%% to be adjusted if n \neq 5
r=r_m*ones(n,1)+h*0.8*r_m*(-2:2)';  %%% to be adjusted if n \neq 5

loopnum=100;
max_time=100;
options=[];

State_Output=nan(length(c1_total), length(c2_total), loopnum, 2);
event_num=zeros(length(c1_total), length(c2_total), loopnum);
real_time=zeros(length(c1_total), length(c2_total), loopnum);


for loop=1:loopnum
    loop

    for c1_index=1:length(c_tot)
        c1=c1_total(c1_index)

        parfor c2_index=1:length(c_tot)
            c2=c2_total(c2_index);

            state=ones(n,2);

            tot_time=0;
            tot_num=0;

            %%%%%%%%%% max_time %%%%%%%%%%

            while tot_time<max_time

                N1=state(:,1);
                N2=state(:,2);
                growth1=r.*N1;
                growth2=r.*N2;
                death1=-r.*N1.*(N1+N2)./K-d1*N1;
                death2=-r.*N2.*(N1+N2)./K-d2*N2;
                propen=[growth1; growth2; death1; death2];

                time_rand=unifrnd(0, 1, 4*n, 1);
                tau=abs(log(time_rand)./propen);
                [mintau, minindex]=min(tau);

                tspan=[0 mintau];
                y0=[state(:,1); state(:,2)];
                [t,y]=ode45('dem_LV_dispersal',tspan,y0,options,n,2,c1,c2,dis_mode);
                state=[y(length(t),1:n)' y(length(t),n+1:2*n)'];

                state_change=zeros(n, 2);  %% initial value

                if minindex<=n
                    state_change(minindex,1)=1;
                elseif minindex>n && minindex<=2*n
                    state_change(minindex-n,2)=1;
                elseif minindex>2*n && minindex<=3*n
                    state_change(minindex-2*n,1)=-1;
                elseif minindex>3*n && minindex<=4*n
                    state_change(minindex-3*n,2)=-1;
                end

                state=state+state_change;
                state(state<0)=0;

                tot_num=tot_num+1;
                tot_time=tot_time+mintau;

                if mintau==Inf  %% which means all Ns = 0
                    break
                end

            end

            real_time(c1_index, c2_index, loop)=tot_time;
            event_num(c1_index, c2_index, loop)=tot_num;

            if tot_time>=max_time
            output=[sum(state(:,1)),sum(state(:,2))];
            State_Output(c1_index, c2_index, loop, :) = output;
            end
            
        end
    end
end

toc


%%%%%% Plot Figures S10 and S11

grade_all=State_Output(:,:,:,1)./(State_Output(:,:,:,1)+State_Output(:,:,:,2));
grade=mean(grade_all,3);
c1_tot=c_tot;
c2_tot=c_tot;

colors=[255, 230, 150; 255 0 0; 255, 150, 230]/255;

num_colors = 256; 
my_colormap = zeros(num_colors, 3);

my_colormap(1:round(0.1*num_colors), :) = repmat(colors(1, :), round(0.1*num_colors), 1);
my_colormap(round(0.1*num_colors)+1:round(0.9*num_colors), :) = repmat(colors(2, :), round(0.9*num_colors)-round(0.1*num_colors), 1);
my_colormap(round(0.9*num_colors)+1:end, :) = repmat(colors(3, :), num_colors-round(0.9*num_colors), 1);

min_value = min(grade, [], 'all'); 
max_value = max(grade, [], 'all');

start_idx = round(min_value * num_colors) + 1;
end_idx = round(max_value  * num_colors);

start_idx = max(1, start_idx);
end_idx = min(num_colors, end_idx);

gca=pcolor(c2_tot, c1_tot, grade);
set(gca, 'LineStyle','none');
% shading interp;
grid off
colormap(my_colormap(start_idx:end_idx, :));
line([-5,3],[-5,3],'linestyle','--','color','k');