clear all
clc

tic

m=0.5;
a=1;
K=50;
mu=10;
A_m=300;
gamma=1;
e1=0.18;
e2=0.15;


% % dispersal
% dis_mode=0;
% loopnum=100;
% max_time=200;
% %%% corresoponds to 6~8e4 birth/death events
% valid_num=1e3;
% c_tot=-5:0.5:2;
% c1_total=10.^c_tot;
% c2_total=10.^c_tot;

% colonization
dis_mode=1;
loopnum=100;
max_time=200;
valid_num=1;
c_tot=-4:0.2:-1;
c1_total=10.^c_tot;
c2_total=10.^c_tot;

n=5;
h=0;
%%%% scenario 1: h=0;
%%%% scenario 3: h=0.3;

A=A_m*ones(n,1)+h*A_m*(-2:2)';  %%% to be adjusted if n \neq 5
options=[];

State_Output=nan(length(c1_total),length(c2_total), loopnum, 2);
event_num=zeros(length(c1_total),length(c2_total), loopnum);
real_time=zeros(length(c1_total),length(c2_total), loopnum);


for loop=1:loopnum
    loop

    for c1_index=1:length(c_tot)
        c1=c1_total(c1_index)

        parfor c2_index=1:length(c_tot)
            c2=c2_total(c2_index);

            state=[ones(n,2) A];

            tot_time=0;
            tot_num=0;

            %%%%%%%%%% max_time %%%%%%%%%%

            while tot_time<max_time

                N1=state(:,1);
                N2=state(:,2);
                R=state(:,3);
                growth1=gamma*N1.*e1*mu.*R./(K+R);
                growth2=gamma*N2.*e2*mu.*R./(K+R);
                death1=gamma*N1*m;
                death2=gamma*N2*m;
                propen=[growth1; growth2; death1; death2];

                time_rand=unifrnd(0, 1, 4*n, 1);
                tau=abs(log(time_rand)./propen);
                [mintau, minindex]=min(tau);

                tspan=[0 mintau];
                y0=[state(:,1); state(:,2); state(:,3)];
                [t,y]=ode45('dem_resource_dispersal',tspan,y0,options,n,2,c1,c2,a,A,mu,K,gamma,dis_mode);
                state(:,1)=y(length(t),1:n)';
                state(:,2)=y(length(t),n+1:2*n)';
                state(:,3)=y(length(t),2*n+1:3*n)';

                state_change=zeros(n, 3);  %% initial value

                if minindex<=n
                    state_change(minindex,1)=1;
                elseif minindex>n && minindex<=2*n
                    state_change(minindex-n,2)=1;
                elseif minindex>2*n && minindex<=3*n
                    state_change(minindex-2*n,1)=-1;
                elseif minindex>3*n && minindex<=4*n
                    state_change(minindex-3*n,2)=-1;
                end

                state=state+state_change;
                state(state<0)=0;

                tot_num=tot_num+1;
                tot_time=tot_time+mintau;

                if mintau==Inf  %% which means all Ns = 0
                    break
                end

            end

            real_time(c1_index, c2_index, loop)=tot_time;
            event_num(c1_index, c2_index, loop)=tot_num;

            if tot_time>=max_time
                output=[sum(state(:,1)),sum(state(:,2))];
                State_Output(c1_index, c2_index, loop, :) = output;
            end
        end

    end
end

toc

%%%%%% Plot Figures S12

grade_all=State_Output(:,:,:,1)./(State_Output(:,:,:,1)+State_Output(:,:,:,2));
grade=mean(grade_all,3);
c1_tot=c_tot;
c2_tot=c_tot;

colors=[255, 230, 150; 255 0 0; 255, 150, 230]/255;

num_colors = 256; 
my_colormap = zeros(num_colors, 3);

my_colormap(1:round(0.1*num_colors), :) = repmat(colors(1, :), round(0.1*num_colors), 1);
my_colormap(round(0.1*num_colors)+1:round(0.9*num_colors), :) = repmat(colors(2, :), round(0.9*num_colors)-round(0.1*num_colors), 1);
my_colormap(round(0.9*num_colors)+1:end, :) = repmat(colors(3, :), num_colors-round(0.9*num_colors), 1);

min_value = min(grade, [], 'all'); 
max_value = max(grade, [], 'all');

start_idx = round(min_value * num_colors) + 1;
end_idx = round(max_value  * num_colors);

start_idx = max(1, start_idx);
end_idx = min(num_colors, end_idx);

gca=pcolor(c2_tot, c1_tot, grade);
set(gca, 'LineStyle','none');
% shading interp;
grid off
colormap(my_colormap(start_idx:end_idx, :));
line([-5,3],[-5,3],'linestyle','--','color','k');